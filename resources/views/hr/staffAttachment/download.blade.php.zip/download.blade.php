@extends('layouts.layout')
@section('pageTitle')
 Upload Attachment
@endsection

@section('content')
<div id="page-wrapper" class="box box-default">
  <div class="container-fluid">
    <div class="col-md-12 text-success"><!--2nd col--> 
    </div>
    <br />
    <hr >
    <div class="row">
     <form class="navbar-form navbar-left" action="{{ URL::to('find') }}" method="POST">
		      		{{ csrf_field() }}
		        	<div class="input-group">
		          		<input type="text" id="search" name="search" class="form-control" placeholder="Search Member">
		          		<span class="input-group-btn">
	                  		<button type="submit" class="btn btn-default">
	                   		<span class="glyphicon glyphicon-search"></span>
	                   		</button>
	                	</span>
		        	</div>
		      	</form>
      
         
		 
		   
		 
                      
	
    </div>
  </div>
</div>
<!--
<div id="page-wrapper" class="box box-default">
<div class="box-body">
  <h2 class="text-center">ALL ATTACHMENTS</h2>
  <div class="row"> {{ csrf_field() }}
    <div class="table-responsive col-md-12">
      <table id="mytable" class="table table-bordered table-striped table-highlight">
        <thead>
          <tr bgcolor="#c7c7c7">
            <th>S/N</th>
            <th>STAFF</th>
            <th>DESC</th>
            <th>ATTACHMENT</th>
            <th></th>
                       
          </tr>
        </thead>
               
        <tbody>
        
         
            </tbody>
                   
      </table>
       <hr />
       <div align="right">
      </div>
      <div class="hidden-print"></div>
    </div>
  </div>
-->
  <!-- /.col --> 
  
</div>

<!-- modal bootstrap -->
<form action="{{url('/petition/add')}}" method="post">
{{ csrf_field() }} 
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Update Module</h4>
            </div>
            <div class="modal-body">
           
                    <div class="row" style="margin-bottom: 10px;">
                     <div class="form-group">
                        <label for="section" class="col-md-3 control-label">Module Name</label>
                        <div class="col-md-9">
                          <input id="module" type="text" class="form-control" name="name" required>
                          <input id="id" type="hidden" class="form-control" name="moduleID" required>
                        </div>
                      </div>
                    </div>
                      
                    <div class="row">
                     <div class="form-group">
                       <label for="section" class="col-md-3 control-label">Rank</label>
                        <div class="col-md-9">
                          <input id="ranks" type="number" class="form-control" name="rank" value="" required>
                          
                        </div>
                      </div>
                    </div>    


            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" id="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>

<!--// modal Bootstrap -->
</form>

@endsection 

@section('styles')
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/datepicker.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/custom-style.css')}}">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
@stop

@section('scripts')

<script type="text/javascript" src="{{ asset('tinymce/js/tinymce/tinymce.min.js') }}"></script>
<script src="{{asset('assets/js/jquery-ui.min.js')}}"></script>
<script src="{{ asset('assets/js/jquery.autocomplete.min.js') }}" ></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>


<script type="text/javascript">
$(document).ready(function(){
 $('table tr td .edit').click(function(){
  var id = $(this).attr('id');
//alert(id);
$.ajax({
  url: murl +'/module/modify',
  type: "post",
  data: {'id': id, '_token': $('input[name=_token]').val()},
  success: function(data){
console.log(data.modulename);
   $('#module').val(data.modulename);
   $('#id').val(data.moduleID);
   $('#ranks').val(data.module_rank);
  }
});

});
});
</script>

<script>
$(document).ready(function(){
 
 fetch_customer_data();
 
 function fetch_customer_data(query = '')
 {
  $.ajax({
   url:"{{ route('live_search.action') }}",
   method:'GET',
   data:{query:query},
   dataType:'json',
   success:function(data)
   {
    $('tbody').html(data.table_data);
    $('#total_records').text(data.total_data);
   }
  })
 }
 
 $(document).on('keyup', '#search', function(){
  var query = $(this).val();
  fetch_customer_data(query);
 });
});
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$.ajaxSetup({
			headers: {
			    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
 
		$('#search').keyup(function(){
			var search = $('#search').val();
			if(search==""){
				$("#memList").html("");
				$('#result').hide();
			}
			else{
				$.get("{{ URL::to('search') }}",{search:search}, function(data){
					$('#memList').empty().html(data);
					$('#result').show();
				})
			}
		});
	});
</script>

@stop
