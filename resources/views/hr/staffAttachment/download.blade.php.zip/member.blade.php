@extends('layouts.layout')

@section('content')
<div class="row">

	<h2>{{ $member->first_name }} {{ $member->surname }}</h2>
	<a href="/" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-left"></span> Home</a>
</div>
@endsection
