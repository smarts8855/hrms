@if(count($members) > 0)
	@foreach($members as $member)
		<li><a href="{{ url('member/'.$member->id) }}">{{ $member->first_name }} {{ $member->surname }} {{ $member->othernames}}</a></li>
	@endforeach
@else
	<li>No Results Found</li>
@endif