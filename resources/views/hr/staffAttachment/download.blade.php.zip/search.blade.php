@extends('layouts.layout')

@section('content')
<div class="row">
               
</div> 
<div class="col-md-8 col-md-offset-2">
         <nav class="navbar navbar-default">
	  	<div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    	<div class="navbar-header">
	      		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
	      		</button>
	      		<a class="navbar-brand" href="#">Search Staff</a>
	    	</div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      	<form class="navbar-form navbar-left" action="{{ URL::to('find') }}" method="POST">
		      		{{ csrf_field() }}
		        	<div class="input-group">
		          		<input type="text" id="search" name="search" class="form-control" style="width:800px;" placeholder="Staff Name">
		          		<span class="input-group-btn">
	                  		<button type="submit" class="btn btn-default">
	                   		<span class="glyphicon glyphicon-search"></span>
	                   		</button>
	                	</span>
		        	</div>
		      	</form>
		    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>
	
	<div id="getResult" class="panel panel-default" style="width:400px; height: 200px; overflow-y:auto; position:absolute; left:180px; top:55px; z-index:1; display:none;">
	<div id="getList"></div>
	</div>
	<hr>
	
          
          <hr />
</div>
@endsection