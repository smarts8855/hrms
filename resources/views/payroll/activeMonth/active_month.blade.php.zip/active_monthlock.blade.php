@extends('layouts.layout')

@section('pageTitle')
Set Active Month
@endsection


@section('content')
  <form method="post">
  {{ csrf_field() }}
  <div class="box-body" style="background:#FFF;">
          <div class="row">
            <div class="col-md-12">
              @if (count($errors) > 0)
                        <div class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
                        </button>
                        <strong>Error!</strong> 
                             @foreach ($errors->all() as $error)
                                  <p>{{ $error }}</p>
                             @endforeach
                        </div>
                        @endif                       
                        
                        @if(session('message'))
                        <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
                        </button>
                        <strong>Success!</strong> {{ session('message') }}</div>                        
                        @endif
                        
                        @if(session('error_message'))
	        <div cla<div class="alert alert-danger alert-dismissible" role="alert">
	          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span> </button>
	          <strong>Error!</strong> {{ session('error_message') }}</div>
	        @endif
                        
                        
            </div>

            <!-- 1st column -->
            <div class="col-md-12">
             <h4> Lock Active Month </h4>
           

<div class="form-group">
                  <label >Select a Year</label>
                      <select name="year"  class="form-control">
                                    <option value="">Select Year</option>  
                  <?php $curyr= date("Y"); ?>
                                    @for ($i = $curyr-1; $i <= $curyr+1; $i++)
        				<option value="{{ $i }}" {{(old('year') == $i ||($year) == $i) ? "selected" : ""}}>{{ $i }}</option>
    				    @endfor
                                    </select>
                      </div>


             <div class="form-group">

                        <label> Select a month </label>
                        <select name="month" id="section" class="form-control input-sm">
                        <option value="">Select Month </option>
                        <option value="JANUARY">January</option>
                        <option value="FEBRUARY">February</option>
                        <option value="MARCH">March</option>
                        <option value="APRIL">April</option>
                        <option value="MAY">May</option>
                        <option value="JUNE">June</option>
                        <option value="JULY">July</option>
                        <option value="AUGUST">August</option>
                        <option value="SEPTEMBER">September</option>
                        <option value="OCTOBER">October</option>
                        <option value="NOVEMBER">November</option>
                        <option value="DECEMBER">December</option>
                          </select>
                        

                  </div>

                      <div class="form-group">
                        <div >
                          <button type="submit" name="process" class="btn btn-success btn-sm pull-right">Lock <i class="fa fa-lock"></i></button>
                        </div>
                      </div>                      

              </div>
            <!-- /.col -->

            <!-- /.col -->
          </div>
 

         <div class="row">
            <div class="col-md-12">
</br>

<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">Current Active Month And Year</h3>
  </div>
 <!-- Place table here-->
 <div class="panel-body">
 <table class="table table-responsive table-bordered">
              <thead>
                    <tr>
                        
                        <th>Year</th>
                        <th>Month</th>
						<th>Status</th>
                        
                        
                    </tr>
              <thead>
              <tbody>
              @foreach ($activemonth as $active)
              <tr>
             <td>{{$active->year}}</td>
             <td>{{$active->month}}</td>
            @if($active->status == 'Lock')
			 <td>{{$active->status}}ed <i class="fa fa-lock"></i></td>
			 @else
			 <td>{{$active->status}} <i class="fa fa-lock-o"></i></td>
			 @endif
		
             </tr>
            @endforeach
              </tbody>
        </table>
       
  
  </div>
</div>
                    </div>
                    
</div>
          <!-- /.row -->
        </div>

  </form>


 
@endsection

@section('styles')
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/datepicker.min.css')}}">
@endsection
