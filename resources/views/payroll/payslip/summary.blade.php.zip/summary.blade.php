@extends('layouts.layout')
@section('content')
<div class="box-body" style="background:#FFF;">
  <div>
    <div class="col-md-12" style="background:#FFF;">
      <section style="background:#FFF;">
        <div>
          <div  align="center"><span  class="banner"><h2 style="font-weight: 700;color: green">{{$courtName}}</h2></span>
            <table class="table table-bordered table-condensed" align="right">
              <tr>
                <td colspan="4"><div align="center"><strong>
                  STAFF PAY SLIP</strong></div></td>
                </tr>
                @foreach ($payslip_detail as $reports)
                <tr>
                  <td colspan="2"><div align="left">File No: <strong>{{ $reports->fileNo}} </strong> 
                    <span>Grade: <strong> {{ $reports->grade}} </strong> </span>
                    <span>Step: <strong> {{ $reports->step}} </strong> </span>
                    <br />
                    Full Name: <strong>{{ $reports->surname.' '.$reports->first_name.' '.$reports->othernames}}<br />    
                  </strong>Account No: <strong>  
                  {{$reports->AccNo}} <br />
                </strong>Bank Name: <strong> {{$bank->bank}} 
              </strong><br />        
              Date Printed: <strong> {{Date("F d, Y")}} </strong><br />
              Month: <strong>  {{$reports->month}}  </strong><br />
              Year: <strong> {{$reports->year}}  </strong><br />
              Division: <strong>{{$division->division}} </strong></div>
            </td>
            <td colspan="2" align="right" valign="bottom"><img src="passport/{{$reports->year}}.jpg" width="150" /></td>
          </tr>
          <tr>
            <td colspan="4"><div align="right"><a  class= "no-print" href = "{{ url('/payslip/create') }}">Back</a></div></td>
          </tr> 
          <br>
          <br>
          <tr>
            <td width="271"><strong>Earnings</strong><br /></td>
            <td width="228"><div align="center"><strong>Amount</strong></div></td>
            <td width="292"><strong>Deductions</strong></td>
            <td width="291"><div align="center"><strong>Amount</strong></div></td>
          </tr>
          <tr>
            <td><strong>Basic salary</strong></td>
            <td><div align="right" ><strong> {{number_format($reports->Bs, 2, '.', ',')}} </strong></div></td>
            <td>Tax</td>
            <td><div align="right">{{number_format($reports->TAX, 2, '.', ',')}}</div></td>
          </tr>
          <tr>
            <td>Servant</td>
            <td><div align="right" >{{ number_format($reports->SER , 2, '.', ',')}}</div></td>
            <td>Pension</td>
            <td><div align="right">{{number_format($reports->PEN , 2, '.', ',')}}</div></td>
          </tr>
          <tr>
            <td>Driver</td>
            <td><div align="right">{{ number_format($reports->DR, 2, '.', ',')}}</div></div></td>
            <td>NHF</td>
            <td><div align="right">{{number_format($reports->NHF , 2, '.', ',')}}</div></td>
          </tr>
          <tr>
            <td>Other Earning</td>
            <td><div align="right">{{ number_format($reports->OEarn, 2, '.', ',')}}</div></div></td>
            <td>Other Deductions</td>
            <td><div align="right">{{number_format($reports->OD , 2, '.', ',')}}</div></td>
          </tr>
          
          <tr>
            <td>Housing</td>
            <td><div align="right">{{number_format($reports->HA, 2, '.', ',')}}</div></td>
            <td>Arrears Deduction</td>
            <td><div align="right">{{number_format($reports->AD, 2, '.', ',')}}</div></td>

          </tr>
          <tr>
            <td>Transport</td>
            <td><div align="right">{{number_format($reports->TR, 2, '.', ',')}}</div></td>
            <td></td>
            <td><div align="right"></div></td>
          </tr>
          <tr>
            <td>Utility </td>
            <td><div align="right">{{number_format($reports->UTI, 2, '.', ',')}}</div></td>
            <td></td>
            <td></div></td>
          </tr>
          <tr>
            <td>Furniture</td>
            <td><div align="right">{{number_format($reports->FUR, 2, '.', ',')}}</div></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td>Peculiar</td>
            <td><div align="right">{{number_format($reports->PEC, 2, '.', ',')}}</div></td>
            <td></td>
            <td></td>
          </tr>
          
        
          <tr>
            <td>Arrears</td>
            <td><div align="right">{{number_format($reports->AEarn, 2, '.', ',')}}</div></td>
            <td></td>
            <td><div align="right"></div></td>
          </tr>
         
          <tr>
            <td><strong>Net Pay</strong></td>
            <td><div align="right"><strong>{{number_format($reports->NetPay, 2, '.', ',')}}</strong></div></td>
            <td>&nbsp;</td>
            <td><div align="right"></div></td>
          </tr>
          
          @endforeach
        </table>
      </div>
      <div class="col-md-2 hidden-print"><a href="javascript:0" onclick="window.print();return false;" class="btn btn-success">print</a></div>
    </section>
  </div>
</div>
</div>
@endsection
@section('scripts')
<script type="text/javascript" src="{{ asset('assets/js/number_to_word.js') }}">
@endsection

@section('styles')
<style type="text/css">
.table { border: 1px solid #000; font-size:16px }
.table thead > tr > th { border-bottom: none; }
.table thead > tr > th, .table tbody > tr > th, .table tfoot > tr > th, .table thead > tr > td, .table tbody > tr > td, .table tfoot > tr > td { border: 1px solid #000; }
</style>
@endsection