@extends('layouts.app')
@section('pageTitle', 'List of Bidding Contracts')
@section('pageMenu', 'active')
@section('content')

<div class="row">
    <div class="col-12">
        <div class="card">
            @include('ShareView.operationCallBackAlert')
            <div class="card-body">
                <p class="row">
                @php  $getName = DB::table('tblcontract_details')->where('contract_detailsID',$id)->first();  @endphp
                <h2><strong>{{ $getName->contract_name }}</strong></h2>
                <br/>
                <table class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                    <tr>
                        <th>SN</th>
                        <th>Contractor</th>
                        <th>Contract Amount</th>
                        <th>Bidding Amount</th>
                        <th>Bidding Date</th>
                        <th>Submitted Docs</th>
                        <th>Edit Amount</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                    </thead>

                    @php
                    $n=1;
                    @endphp
                    <tbody>
                    @foreach($getList as $list)
                        
                        <?php
                            $checkAprove = DB::table('tblapproval')->where('bidding_id',$list->contract_biddingID)->where('status_id',3)->exists();
                            //$para = base64_encode($list->contract_biddingID);
                            $documents= app('App\Http\Controllers\ReuseableController')->fetchBiddingDocument($list->contract_biddingID,2);
                            
                            $x = $list->contract_biddingID;
                        ?>
                   
                    <tr @if($list->recommendation==1) style="background-color:#00FF99 !important;" @else @endif>
                        <td>{{$n++}}</td>
                        <td>{{$list->company_name}}</td>
                        <td align="right">{{number_format($list->proposed_budget,2)}}</td>
                        <td align="right">{{ $list->awarded_amount}}</td>
                        <td>{{date("jS M, Y", strtotime($list->date_submitted))}}</td>
                        <td>@foreach($documents as $t)<a href="BiddingDocument/{{$t->file_name}}" target="_blank">{{ $t->file_description }}</a><br/> @endforeach <i data-toggle="modal" data-target="#myModal{{$list->contract_biddingID}}" style="cursor:pointer">view more</i></td>
                         <td>
                            <a data-toggle="modal" data-target="#amtModal{{$list->contract_biddingID}}" target="_blank" style="cursor:pointer;font-style:italic;color:green">Edit Amount</a>&nbsp;
                        </td>
                        <td style="font-size:12px;"><i id="wh">Award</i>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" class="form-check-input" id="recommend{{$list->contract_biddingID}}" name="recommend{{$list->contract_biddingID}}" value="{{$list->contract_biddingID}}" onclick="getValue({{$list->contract_biddingID}})">
                            <span id="award{{$list->contract_biddingID}}">@if($checkAprove==true) <script> document.getElementById("recommend{{$list->contract_biddingID}}").checked = true;  </script>  @else @endif</span>
                        </td>
                    </tr>
                     
                    <!-- The Modal -->
                    <div class="modal" id="myModal{{$list->contract_biddingID}}">
                      <div class="modal-dialog">
                        <div class="modal-content">
                    
                          <!-- Modal Header -->
                          <div class="modal-header">
                            <h4 class="modal-title">Bidding Documents</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                          </div>
                    
                          <!-- Modal body -->
                          <div class="modal-body">
                            <?php
                                $documents= app('App\Http\Controllers\ReuseableController')->fetchBiddingDocument($list->contract_biddingID,10);
                            ?>
                                    @foreach($documents as $a)
                                        <a href="BiddingDocument/{{$a->file_name}}" target="_blank"><p style="background-color:light-green;font-size:18px" class="fa fa-file" > {{ $a->file_description }}  | <i class="fa fa-arrow-down"></i></a></p>
                                        <hr>
                                    @endforeach
                          </div>
                    
                          <!-- Modal footer -->
                          <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          </div>
                    
                        </div>
                      </div>
                    </div>
                    
                    <div class="modal" id="amtModal{{$list->contract_biddingID}}">
                      <div class="modal-dialog">
                        <div class="modal-content">
                    
                          <!-- Modal Header -->
                          <div class="modal-header">
                            <h4 class="modal-title">Edit Amount</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                          </div>
                        <form method="post" action="{{ route('updateAmt') }}">
                            @csrf
                          <!-- Modal body -->
                          <div class="modal-body">
                            <div class="form-group">
                                <input type="hidden" class="form-control" name="id" id="id" value="{{ $list->contract_biddingID }}" required>
                              <label for="usr">Amount:</label>
                              <input type="text" class="form-control bidAmt" name="amount" id="biddingAmount{{ $list->contract_biddingID }}" value="{{ $list->awarded_amount }}" required>
                            </div>
                          </div>
                       
                          <!-- Modal footer -->
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Update</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          </div>
                         </form>
                        </div>
                      </div>
                    </div>
                    
                    <!--approve for single contractor-->
                    <div class="modal" id="apprModal{{$list->contract_biddingID}}" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
                      <div class="modal-dialog">
                        <div class="modal-content">
                    
                          <!-- Modal body -->
                          <div class="modal-body">
                              <form method="post" action="{{ route('approveBidder') }}">  
                              @csrf
                              <div class="form-group">
                              <input type="hidden" class="form-control" id="cidx" name="cidx" value="{{$list->contract_biddingID}}">
                            </div>
                             <div class="form-group">
                              <label for="comment">Comment:</label>
                              <textarea class="form-control" rows="3" id="comment" name="comment"></textarea>
                            </div> 
                          </div>
                    
                          <!-- Modal footer -->
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Submit</button>
                            <button type="button" class="btn btn-danger" id="nonaward{{$list->contract_biddingID}}" data-dismiss="modal" onclick="nonAward({{$list->contract_biddingID}})">Close</button>
                          </div>
                            </form>
                        </div>
                      </div>
                    </div>
                    
                    <!-- End Modal-->
                    <script>
                       
                        function getValue(x)
                        {
                            //alert(x);
                           var checkBox = document.getElementById("recommend"+x);
                           var contractID = x ;
                           
                           if (checkBox.checked == true)
                           {
                               $("#award"+x).empty();
                               //$("#award"+x).append(" ");
                        		$.ajax({
                        		      
                        			  url: murl +'/approve-contractor',
                        			  type: "post",
                        			  data: {'contractID':contractID, '_token': $('input[name=_token]').val()},
                        			  success: function(data){
                        			 
                        			   //console.log(data);
                        			  $("#award"+x).empty();
                                      //$("#award"+x).append("Awarded");
                        			  
                        			  }
                        		});
                        		
                        		document.getElementById("wh").style.display="none";
                        		//document.getElementById("whx").style.display="block";
                        		
                        		$("#apprModal"+x).attr('style', 'display:block;');
                            	$('#apprModal'+x).modal({backdrop: true, keyboard: false, show: true});
                            	$('#apprModal'+x).data('bs.modal').options.backdrop = 'static';
                        		$("#apprModal"+x).modal('show')
                        	
                            }
                            else{
                                 $("#award"+x).empty();
                                 //$("#award"+x).append(" ");
                                 
                                	$.ajax({
                                	  
                        			  url: murl +'/remove-contractor',
                        			  type: "post",
                        			  data: {'contractID':contractID, '_token': $('input[name=_token]').val()},
                        			  success: function(data){
                        			  
                        			  //console.log(data);
                        			  $("#award"+x).empty();
                                      //$("#award"+x).append(" ");
                        			  }
                        		});
                        		//document.getElementById("wh").style.display="block";
                        		//document.getElementById("whx").style.display="none";
                        		
                        	    $("#apprModal"+x).modal('show')
                            }
                            
                        }
                        
                        //non award function
                        function nonAward(y)
                        {
                            
                           var btnNon = document.getElementById("nonaward"+y).value;
                           var contractID = y ;
                         
                                 $("#award"+y).empty();
                                 //$("#award"+y).append(" ");
                                 
                                	$.ajax({
                                	  
                        			  url: murl +'/remove-contractor',
                        			  type: "post",
                        			  data: {'contractID':contractID, '_token': $('input[name=_token]').val()},
                        			  success: function(data){
                        			  
                        			  //console.log(data);
                        			  $("#award"+y).empty();
                                      $("#award"+y).append(" ");
                        			  }
                        			  
                        		});
                        	
                            document.getElementById("recommend"+y).checked=false;
                            //document.getElementById('cid').value=x;
                        }
                        
                        
                    </script>
                    
                    @endforeach
                    </tbody>
                </table>
                
                <button data-toggle="modal" data-target="#approvalModal"  class="btn btn-outline-primary" id="approval_comment" style="margin-left:6px;">Approve</button>
                <button data-toggle="modal" data-target="#rejectModal" class="btn btn-outline-success" id="" style="margin-left:6px;">Reject</button>
                
            </div>
        </div>
    </div> <!-- end col -->
   
</div> <!-- end row -->

<!-- Modal  -->

<!-- Button to Open the Modal -->
<!-- The Modal -->
<div class="modal" id="approvalModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Approve Contract</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
            <?php
                $comments= app('App\Http\Controllers\ReuseableController')->getComments($list->contractID);
            ?>
          <div style="padding: 15px; height:150px; overflow-y: scroll;">
            <h6 class="modal-title"><strong>Comments:</strong></h6>
            <br/>
             @foreach($comments as $c)
                <p style="font-style:italic; border-bottom:solid;border-width:thin"><strong style="font-weight:bold;color:green">{{$c->name}}:</strong> {{$c->comment_description}} <i style="font-size:11px;color:red">[{{$c->created_at}}]</i></p>
             @endforeach
          </div>
         
          <form method="post" action="{{ route('approve') }}">  
          @csrf
          <div class="form-group">
          <label for="usr">Date:</label>
          <input type="date" class="form-control" id="date" name="date">
          <input type="hidden" class="form-control" id="cid" name="cid" value="{{ $list->contractID}}">
        </div>
         <div class="form-group">
          <label for="comment">Comment:</label>
          <textarea class="form-control" rows="2" id="comment" name="comment"></textarea>
        </div> 
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Approve</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
        </form>
    </div>
  </div>
</div>

<div class="modal" id="rejectModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Reject Contract</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
            <?php
                $comments= app('App\Http\Controllers\ReuseableController')->getComments($list->contractID);
            ?>
          <div style="padding: 15px;height:150px;overflow-y: scroll;">
            <h6 class="modal-title"><strong>Comments:</strong></h6>
            <br/>
              @foreach($comments as $c)
                <p style="font-style:italic; border-bottom:solid;border-width:thin"><strong style="font-weight:bold;color:green">{{$c->name}}:</strong> {{$c->comment_description}} <i style="font-size:11px;color:red">[{{$c->created_at}}]</i></p>
             @endforeach
          </div>
         
      <!-- Modal body -->
      <div class="modal-body">
          <form method="post" action="{{ route('reject') }}">  
          @csrf
          <div class="form-group">
          <label for="usr">Date:</label>
          <input type="date" class="form-control" id="date" name="date">
          <input type="hidden" class="form-control" id="cid" name="cid" value="{{ $list->contractID}}">
        </div>
         <div class="form-group">
          <label for="comment">Comment:</label>
          <textarea class="form-control" rows="2" id="comment" name="comment"></textarea>
        </div> 
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Reject</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
        </form>
    </div>
  </div>
</div>

<!-- End Modal-->

@endsection

@section('styles')
<link href="{{ asset('assets/css/select2.min.css') }}" id="app-style" rel="stylesheet" type="text/css" />

@endsection

@section('scripts')
<script src="{{ asset('assets/js/select2.min.js') }}"></script>
<script src="{{ asset('assets/js/select2.min.js') }}"></script>
<script>
$(document).ready(function () {
$(".bidAmt").on('keyup', function(evt){
//if (evt.which != 110 ){//not a fullstop
//var n = parseFloat($(this).val().replace(/\,/g,''),10);

 $(this).val(function (index, value) {
return  value.replace(/(?!\.)\D/g, "").replace(/(?<=\..*)\./g, "").replace(/(?<=\.\d\d).*/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    });
//$(this).val(n.toLocaleString());
//}
});
});
</script>
@endsection
