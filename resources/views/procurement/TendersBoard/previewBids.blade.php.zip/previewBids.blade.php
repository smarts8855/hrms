@extends('layouts.app')
@section('pageTitle', 'Bids for Approval')
@section('pageMenu', 'active')
@section('content')
@include('Bank.layouts.messages')

<h2 style="margin-left:14px; margin-bottom:26px;">Contract: {{strtoupper($contract->contract_name)}}</h2>
<div class="row">
    
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                  <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                    <tr>
                        <th>SN</th>
                        <th>Contractor</th>
                        <th>Amount</th>
                        <th>Date Submitted</th>
                        <th>Documents</th>
                        <th>Recommended Bid</th>
                        <th>Edit Amount</th>
                        <th>Actions</th>
                      
                    </tr>
                    </thead>


                    <tbody>
                        <p style="display:none"></p>
                        <?php
                        $n = 1;
                        ?>
                        
                        @foreach($display as $data)
                        @php
                        $doc = DB::table('tblcontractor_bidding_document')->where('biddingID','=',$data->contract_biddingID)->get();
                        $awarded = DB::table('tblcontract_award')->where('contractID','=',$data->contractID)->where('contractorID','=',$data->contractor_registrationID)->count();
                        @endphp
                   <tr @if($awarded ==1) style="background:green !important; color:white;" @endif @if($data->recommendation ==1) style="background:orange;color:white;" @endif >
                        <td>{{$n++}}</td>
                        <td>{{$data->company_name}}</td>
                        <td align="right">@if($data->awarded_amount == ''){{number_format($data->bidding_amount,2)}} @else {{number_format($data->awarded_amount,2)}} @endif</td>
                        <td align="right">{{date("jS M, Y", strtotime($data->date_submitted))}}</td>
                        <td>
                        <span>{{count($doc)}} document(s) </span> |
                        <a class="viewDocs" href="javascript:void()" bidId="{{$data->contract_biddingID}}" @if($data->recommendation ==1) style="color:white;" @endif @if($awarded ==1) style="color:white;" @endif>View Docs</a>
                            
                        <!-- Document View Modal -->
                        <div id="docModal" class="modal fade doc{{$data->contract_biddingID}}">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3>Bidding Documents</h3>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        
                                        <p id="message"></p>
                                    </div>
                                    
                                    <div class="modal-body">
                                    <p id="docsAreas">
                                        @foreach($doc as $docs)
                                        <p>
                                        <a href="{{url('/BiddingDocument/'.$docs->file_name)}}" style="font-size:16px;" target="_blank">  {{$docs->file_description}}  | <i style="border-radius:48%;" class="fa fa-arrow-down btn btn-success"></i></a>
                                        </p>
                                        @endforeach
                                        
                                    </p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
                                        
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                        <!--// Document View Modal end-->
                                    
                        </td>
                        <td> @if($data->recommendation ==1) Recommended Bid @endif </td>
                        <td><a href="javscript:void()" class="edit" bidId="{{$data->contract_biddingID}}" contractorId="{{$data->contractor_registrationID}}" contractId="{{$data->contractID}}" >Edit Amount</a></td>
                        <td>
                            @if($awarded ==1) 
                            <p style="color:white; padding:0; margin:0">Awarded  | <a href="javascript:void()" bidId="{{$data->contract_biddingID}}" contractorId="{{$data->contractor_registrationID}}" contractId="{{$data->contractID}}" class="reverse"> Reverse</a></p>
                            @elseif($data->recommendation ==1)
                            <a href="javascript:void()" bidId="{{$data->contract_biddingID}}" contractorId="{{$data->contractor_registrationID}}" contractId="{{$data->contractID}}" class="award" style="color:white; padding:0; margin:0"> Award</a>
                            @else
                          <a href="javascript:void()" bidId="{{$data->contract_biddingID}}" contractorId="{{$data->contractor_registrationID}}" contractId="{{$data->contractID}}" class="award"> Award</a>
                          @endif
                        </td>
                    </tr>
                        @endforeach
                        <form method="post" action="{{url('/final-contract/award')}}">
                            {{ csrf_field() }}
                        <tr>
                            <td colspan="7" >
                        
                            <input type="hidden" name="contract" class="btn btn-success" value="{{$contractID}}">
                            <input type="submit" name="submit" class="btn btn-success float-right" onclick="return confirmAction();" value="Approve">
                        
                        </td>
                        </tr>
                        </form>
                    
                    

                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->

<!-- modal -->

<div id="approveModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Make your comment</h3>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                
                <p id="message"></p>
            </div>
            <form method="post" action="{{url('/contract/awarding')}}">
                {{ csrf_field() }}
            <div class="modal-body">
            
                
                <input type="hidden" name="bidid" class="bidid"/>
                <input type="hidden" name="contractID" class="contractID"/>
                <input type="hidden" name="contractorID" class="contractorID"/>
                
            <div class="form-group">
                <label>Award Comment</label>
                <textarea class="form-control" name="comment"></textarea>
            </div>
           
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary adv" id="adv">Save</button>
            </div>
            </form>
        </div>
    </div>
</div>


<!-- modal -->


<!--Edit Amount modal -->

<div id="amountModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Adjust Award Amount</h3>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                
                <p id="message"></p>
            </div>
            <form method="post" action="{{url('/adjust/contract/amount')}}">
                {{ csrf_field() }}
            <div class="modal-body">
            
                
                <input type="hidden" name="bidid" class="bidid"/>
                <input type="hidden" name="contractID" class="contractID"/>
                <input type="hidden" name="contractorID" class="contractorID"/>
                
            <div class="form-group">
                <label>Amount</label>
                <input class="form-control" name="amount" id="adjustAmount" placeholder="0">
            </div>
           
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary adv" id="adv">Save</button>
            </div>
            </form>
        </div>
    </div>
</div>


<!--// Edit Amount modal -->


<!-- Document View Modal -->
<div id="docModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Make your comment</h3>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                
                <p id="message"></p>
            </div>
            
            <div class="modal-body">
            <p id="docsArea">
                
            </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary adv" id="adv">Save</button>
            </div>
           
        </div>
    </div>
</div>
<!--// Document View Modal end-->

<!-- reverse modal -->

<div id="reverseModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Make your comment</h3>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                
                <p id="message"></p>
            </div>
            <form method="post" action="{{url('/contract-award/reverse')}}">
                {{ csrf_field() }}
            <div class="modal-body">
            
                <input type="hidden" name="bidid" class="bidid"/>
                <input type="hidden" name="contractID" class="contractID"/>
                <input type="hidden" name="contractorID" class="contractorID"/>
                
            <h5>Do you really want to reverse this award?</h5>
           
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary adv" id="adv">Save</button>
            </div>
            </form>
        </div>
    </div>
</div>


<!-- /// end reverse modal -->

<!-- approval modal-->

<div id="approveAwardModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Your Remark</h3>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                
                <p id="message"></p>
            </div>
            
            <div class="modal-body">
                <form method="post" action="">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="">Your Remark <span class="compulsory">*</span></label>
                                <textarea class="form-control" name="remark" required>Remark</textarea>
                                
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="">Attach Minutes <span class="compulsory">*</span></label>
                                <input type="file" name="doc" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                               <input type="submit" name="submit" class="btn btn-success" value="Approve"/>
                            </div>
                        </div>
                    </div>
                </form>
            <p id="docsArea">
                
            </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                
            </div>
           
        </div>
    </div>
</div>

<!-- aproval modal --></1-->

@endsection

@section('styles')
   
@endsection

@section('scripts')

<script>
function confirmAction()
{
    var c = confirm('Do you actually want to approve?');
    if(c)
    {
        return true;
    }
    else
    {
        return false;
    }
}
</script>

<script>
    $(document).ready(function(){
  
    $("table tr td .viewDocs").click(function(){
        
      var bid = $(this).attr('bidid');
       $('.doc'+bid).modal('show');
       
       /*$.ajax({
      
      url: "{{ url('/get/docs') }}",
    
      type: "post",
      data: {'bidID': bid, '_token': $('input[name=_token]').val()},
      success: function(data){
          console.log(data);
          $('#docsArea').empty();
        $.each(data, function(index, obj){
        
        var url = '';
$("#docsArea").append('<p><a href="/BiddingDocument/'+obj.file_name+'" target="_blank">  '+obj.file_description+'  | <i class="fa fa-arrow-down"></i></a></p>');                               
        });
        
      //location.reload(true);
      
      }
    });*/
      
    
        
    });

});
</script>

<script>
    $(document).ready(function(){
  
    $("table tr td .award").click(function(){
      var bid = $(this).attr('bidid');
      var contract = $(this).attr('contractId');
      var contractor = $(this).attr('contractorId');
      $('.bidid').val(bid);
      $('.contractID').val(contract);
      $('.contractorID').val(contractor);
     $("#approveModal").modal('show');
        
    });

});
</script>
<script>
    $(document).ready(function(){
  
    $("table tr td .reverse").click(function(){
      var bid = $(this).attr('bidid');
      var contract = $(this).attr('contractId');
      var contractor = $(this).attr('contractorId');
      $('.bidid').val(bid);
      $('.contractID').val(contract);
      $('.contractorID').val(contractor);
     $("#reverseModal").modal('show');
        
    });

});
</script>

<script>
    $(document).ready(function(){
  
    $("table tr td .edit").click(function(){
      var bid = $(this).attr('bidid');
      var contract = $(this).attr('contractId');
      var contractor = $(this).attr('contractorId');
      $('.bidid').val(bid);
      $('.contractID').val(contract);
      $('.contractorID').val(contractor);
     $("#amountModal").modal('show');
        
    });

});
</script>
<script type="text/javascript">
    
    var state = false
    var mike
    $('#to_secretary').prop('disabled',true)
    $('.recommend_option').click(function(){
        state = !state
        $('.recommend_option').prop('disabled',state)
        mike = $(this).val()
        $('#to_secretary').prop('disabled',!state)
        $("#recommendedID").val($(this).val());
        
        $(this).prop('disabled',false)
    });   
    var x = document.getElementsByClassName('recommend_option')
 
</script>

<script>

  $("#adjustAmount").on('keyup', function(evt){
    var n = parseFloat($(this).val().toFixed(2).replace(/\D/g,''),10);
    //var n = $(this).val().toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
    if($(this).val() == "")
    {
      $(this).val(0);  
    }
    else
    {
        $(this).val(n.toLocaleString('en'));
    }
});
</script>
@endsection